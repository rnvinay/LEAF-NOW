<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "leafnow";
$conn = mysqli_connect($servername , $username , $password ,$database);

?>